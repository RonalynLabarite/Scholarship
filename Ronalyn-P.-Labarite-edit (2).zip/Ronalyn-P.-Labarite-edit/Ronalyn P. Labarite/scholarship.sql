-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 31, 2023 at 09:41 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `scholarship`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `admin_id` int(50) NOT NULL,
  `username` varchar(10) NOT NULL,
  `password` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`admin_id`, `username`, `password`) VALUES
(1, 'admin', 12345),
(2, 'ebyang', 909);

-- --------------------------------------------------------

--
-- Table structure for table `available_scholar`
--

CREATE TABLE `available_scholar` (
  `scholar_id` int(50) NOT NULL,
  `DOST` varchar(50) NOT NULL,
  `CHED` varchar(50) NOT NULL,
  `TES` varchar(50) NOT NULL,
  `OWWA` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `Student_id` int(50) NOT NULL,
  `First_Name` varchar(11) NOT NULL,
  `Last_Name` varchar(11) NOT NULL,
  `Gender` varchar(50) NOT NULL,
  `Address` varchar(10) NOT NULL,
  `Year_level` int(50) NOT NULL,
  `Course` varchar(10) NOT NULL,
  `Birthday` date NOT NULL,
  `Scholarship` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`Student_id`, `First_Name`, `Last_Name`, `Gender`, `Address`, `Year_level`, `Course`, `Birthday`, `Scholarship`) VALUES
(1, 'Ronalyn', 'Labarite', 'Female', 'Tubod, Sil', 2, 'BSIT', '0000-00-00', 'OWWA'),
(2, 'Ranie', 'Camangian', 'Male', 'Cabalian S', 4, 'BSOA', '0000-00-00', 'DOST'),
(3, 'Jomari', 'Lacano', 'Male', 'Tabok, Sil', 3, 'BSIT', '0000-00-00', 'TES'),
(4, 'Ariane Jane', 'Almine', 'Female', 'Calag-itan', 2, 'BSA', '0000-00-00', 'DSWD'),
(5, 'Angelo', 'Licmoan', 'Male', 'San Jose,C', 2, 'BSInduTech', '0000-00-00', 'TES'),
(6, 'Justine Ann', 'Dadap', 'Female', 'Sta. Cruz,', 1, 'BSE', '0000-00-00', 'OWWA'),
(7, 'Jessica', 'Castulo', 'Female', 'Basak, Cab', 2, 'BSIT', '0000-00-00', 'DOST'),
(8, 'Nhemuel', 'Buctot', 'Male', 'Basak, Sil', 2, 'BSIndutech', '0000-00-00', 'TES');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `available_scholar`
--
ALTER TABLE `available_scholar`
  ADD PRIMARY KEY (`scholar_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`Student_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
  MODIFY `admin_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `available_scholar`
--
ALTER TABLE `available_scholar`
  MODIFY `scholar_id` int(50) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `Student_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
