﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using Newtonsoft.Json;
using System.Net.Http;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using RestSharp;
using Newtonsoft.Json.Linq;

namespace Scholarship_Information_System
{
    class Connection
    {
        public static void dgvViewing( DataGridView dgv)
        {
            try
            {
                RestClient client = new RestClient("http://localhost:3000");
                var request = new RestRequest("student", Method.GET);
                request.AddHeader("authorization", InfoStorage.infoSet.token);
                var response = client.Execute(request);

                if (response.IsSuccessful)
                {

                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(response.Content);
                    dgv.DataSource = dt;
                    dgv.Columns[0].Visible = false;


                }
                else
                {
                    MessageBox.Show("Error fetching data");
                }
            }
            catch
            {

            }
        }
        public static void saveData(string[] columnName, string[] data)
        {
            try
            {
                RestClient client = new RestClient("http://localhost:3000");
                var request = new RestRequest("scholarship", Method.POST);
                request.AddHeader("authorization", InfoStorage.infoSet.token);
                for (int i = 0; i < data.Length; i++)
                {
                    request.AddQueryParameter(columnName[i], data[i]);
                }
                var response = client.Execute(request);
                if (response.IsSuccessful)
                {

                }
                else
                {
                    MessageBox.Show("Fill up incomplete" + response.ErrorMessage);
                }
            }
            catch
            {
            }
        }
        public static void updateData( string[] columnName, string[] data, int id)
        {
            try
            {
                RestClient client = new RestClient("http://localhost:3000");
                var request = new RestRequest("scholarship", Method.PUT);
                request.AddHeader("authorization", InfoStorage.infoSet.token);

                request.AddQueryParameter("Student_id", id.ToString());
                for (int i = 0; i < columnName.Length; i++)
                {
                    request.AddQueryParameter(columnName[i], data[i]);
                }
                var response = client.Execute(request);
                if (response.IsSuccessful)
                {

                }
                else
                {
                    MessageBox.Show("Fill up incomplete!!" + response.ErrorMessage);
                }
            }
            catch
            {
            }
        }
        public static void deleteData( int id)
        {
            try
            {
                RestClient client = new RestClient("http://localhost:3000");
                var request = new RestRequest("scholarship", Method.DELETE);
                request.AddHeader("authorization", InfoStorage.infoSet.token);
                request.AddQueryParameter("Student_id", id.ToString());
                var response = client.Execute(request);
                if (response.IsSuccessful)
                {
                }
                else
                {
                    MessageBox.Show("Error: mmm" + response.ErrorMessage);
                }
            }
            catch
            {
            }
        }
        public static Boolean AccountVerifier(TextBox username, TextBox password)
        {
            bool verify = false;
            try
            {
                RestClient client = new RestClient("http://localhost:3000");
                var request = new RestRequest("login", Method.POST);
                request.AddQueryParameter("username", username.Text);
                request.AddQueryParameter("password", password.Text);

                var response = client.Execute(request);
                if (response.ContentLength > 2)
                {
                    JArray jsonArray = JArray.Parse(response.Content);
                    DataTable dt = JsonConvert.DeserializeObject<DataTable>(jsonArray.ToString());
                    verify = true;

                    InfoStorage.infoSet.token = (dt.Rows[0]["token"]).ToString();
                }
            }
            catch
            {
            }
            return verify;
        }

    }
   
}
      
    
