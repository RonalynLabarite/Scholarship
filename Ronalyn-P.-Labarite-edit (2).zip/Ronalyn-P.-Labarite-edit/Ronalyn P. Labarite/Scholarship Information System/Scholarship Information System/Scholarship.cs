﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Scholarship_Information_System
{
    public partial class Scholarship : Form
    {
        public Scholarship()
        {
            InitializeComponent();

        }

        private void btnScholarshipLogout_Click(object sender, EventArgs e)
        {
            this.Close();
            Home back = new Home();
            back.Show();
        }

        private void btnDost_Click(object sender, EventArgs e)
        {
            DOST Dost = new DOST();
            Dost.Show();
            this.Hide();
        }

        private void btnChed_Click(object sender, EventArgs e)
        {
            Ched ched = new Ched();
            ched.Show();
            this.Hide();
        }

        private void btnTes_Click(object sender, EventArgs e)
        {
            TES Tes = new TES();
            Tes.Show();
            this.Hide();
        }

        private void btnOwwa_Click(object sender, EventArgs e)
        {
            OWWA owwa = new OWWA();
            owwa.Show();
            this.Hide();
        }
    }
}
