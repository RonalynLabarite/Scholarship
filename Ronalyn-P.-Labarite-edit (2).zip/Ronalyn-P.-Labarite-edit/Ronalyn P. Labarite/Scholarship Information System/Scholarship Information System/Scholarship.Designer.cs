﻿namespace Scholarship_Information_System
{
    partial class Scholarship
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnDost = new System.Windows.Forms.Button();
            this.btnChed = new System.Windows.Forms.Button();
            this.btnTes = new System.Windows.Forms.Button();
            this.btnOwwa = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Stencil", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(120, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(343, 33);
            this.label1.TabIndex = 1;
            this.label1.Text = "Scholarship Program";
            // 
            // btnDost
            // 
            this.btnDost.Font = new System.Drawing.Font("Microsoft YaHei", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDost.Location = new System.Drawing.Point(172, 92);
            this.btnDost.Name = "btnDost";
            this.btnDost.Size = new System.Drawing.Size(233, 77);
            this.btnDost.TabIndex = 2;
            this.btnDost.Text = "Department of Science and Technology(DOST)";
            this.btnDost.UseVisualStyleBackColor = true;
            this.btnDost.Click += new System.EventHandler(this.btnDost_Click);
            // 
            // btnChed
            // 
            this.btnChed.Font = new System.Drawing.Font("Microsoft YaHei", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChed.Location = new System.Drawing.Point(172, 195);
            this.btnChed.Name = "btnChed";
            this.btnChed.Size = new System.Drawing.Size(233, 77);
            this.btnChed.TabIndex = 3;
            this.btnChed.Text = "Commission on Higher Education(CHED)";
            this.btnChed.UseVisualStyleBackColor = true;
            this.btnChed.Click += new System.EventHandler(this.btnChed_Click);
            // 
            // btnTes
            // 
            this.btnTes.Font = new System.Drawing.Font("Microsoft YaHei", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTes.Location = new System.Drawing.Point(172, 296);
            this.btnTes.Name = "btnTes";
            this.btnTes.Size = new System.Drawing.Size(233, 76);
            this.btnTes.TabIndex = 4;
            this.btnTes.Text = "Tertiary Education Subsidy(TES)";
            this.btnTes.UseVisualStyleBackColor = true;
            this.btnTes.Click += new System.EventHandler(this.btnTes_Click);
            // 
            // btnOwwa
            // 
            this.btnOwwa.Font = new System.Drawing.Font("Microsoft YaHei", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOwwa.Location = new System.Drawing.Point(172, 400);
            this.btnOwwa.Name = "btnOwwa";
            this.btnOwwa.Size = new System.Drawing.Size(233, 76);
            this.btnOwwa.TabIndex = 5;
            this.btnOwwa.Text = "Overseas Workers Welfare Administration(OWWA)";
            this.btnOwwa.UseVisualStyleBackColor = true;
            this.btnOwwa.Click += new System.EventHandler(this.btnOwwa_Click);
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnBack.Font = new System.Drawing.Font("Cooper Black", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.Location = new System.Drawing.Point(226, 508);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(137, 49);
            this.btnBack.TabIndex = 6;
            this.btnBack.Text = "BACK";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnScholarshipLogout_Click);
            // 
            // Scholarship
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(581, 605);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnOwwa);
            this.Controls.Add(this.btnTes);
            this.Controls.Add(this.btnChed);
            this.Controls.Add(this.btnDost);
            this.Controls.Add(this.label1);
            this.Name = "Scholarship";
            this.Text = "Scholarship";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnDost;
        private System.Windows.Forms.Button btnChed;
        private System.Windows.Forms.Button btnTes;
        private System.Windows.Forms.Button btnOwwa;
        private System.Windows.Forms.Button btnBack;
    }
}