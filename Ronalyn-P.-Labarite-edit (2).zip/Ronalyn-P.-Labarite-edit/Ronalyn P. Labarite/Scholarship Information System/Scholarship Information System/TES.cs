﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Scholarship_Information_System
{
    public partial class TES : Form
    {
        public TES()
        {
            InitializeComponent();
        }

        private void btnScholarshipLogout_Click(object sender, EventArgs e)
        {
            this.Close();
            Scholarship back = new Scholarship();
            back.Show();
        }
    }
}
