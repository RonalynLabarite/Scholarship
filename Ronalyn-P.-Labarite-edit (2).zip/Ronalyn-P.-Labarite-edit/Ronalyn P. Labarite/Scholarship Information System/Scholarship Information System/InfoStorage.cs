﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Scholarship_Information_System
{
    class InfoStorage
    {
        public static Admin infoSet = new Admin();
    }
}
