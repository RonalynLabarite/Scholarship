﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Scholarship_Information_System
{
    class Admin
    {
        public string token { get; set; }
        public string username { get; set; }
        public string password { get; set; }
        
    }
}
