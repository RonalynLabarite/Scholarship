﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Scholarship_Information_System
{
    public partial class Student : Form
    {
        public Student()
        {
            InitializeComponent();
        }
        int id;
        private void Student_Load(object sender, EventArgs e)
        {
            Connection.dgvViewing(dgvStudent);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string[] column = { "First_Name","Last_Name","Gender","Address","Year_level","Course","Birthday","Scholarship" };
            string[] data = { tbxFirstName.Text, tbxLastName.Text, tbxGender.Text, tbxAddress.Text ,tbxYearLevel.Text , tbxCourse.Text , dtpBirthday.Text , tbxScholarship.Text };
            Connection.saveData(column,data);
        }

        private void btnScholarshipLogout_Click(object sender, EventArgs e)
        {
            this.Close();
            Home back = new Home();
            back.Show();
        }

        private void btnViewRecords_Click(object sender, EventArgs e)
        {
            Connection.dgvViewing(dgvStudent);
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string[] column = { "First_Name", "Last_Name", "Gender", "Address", "Year_level", "Course", "Birthday", "Scholarship" };
            string[] data = { tbxFirstName.Text, tbxLastName.Text, tbxGender.Text, tbxAddress.Text, tbxYearLevel.Text, tbxCourse.Text, dtpBirthday.Text, tbxScholarship.Text };
            Connection.updateData(column, data,id);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            Connection.deleteData(id);
        }

        private void dgvStudent_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                tbxStudentId.Text = dgvStudent.Rows[e.RowIndex].Cells[0].Value.ToString();
                id = int.Parse(dgvStudent.Rows[e.RowIndex].Cells[0].Value.ToString());
                tbxFirstName.Text = dgvStudent.Rows[e.RowIndex].Cells[1].Value.ToString();
                tbxLastName.Text = dgvStudent.Rows[e.RowIndex].Cells[2].Value.ToString();
                tbxGender.Text = dgvStudent.Rows[e.RowIndex].Cells[3].Value.ToString();
                tbxAddress.Text = dgvStudent.Rows[e.RowIndex].Cells[4].Value.ToString();
                tbxYearLevel.Text = dgvStudent.Rows[e.RowIndex].Cells[5].Value.ToString();
                tbxCourse.Text = dgvStudent.Rows[e.RowIndex].Cells[6].Value.ToString();
                tbxScholarship.Text = dgvStudent.Rows[e.RowIndex].Cells[8].Value.ToString();
                dtpBirthday.Value = Convert.ToDateTime(dgvStudent.Rows[e.RowIndex].Cells[7].Value);
                
            }
            catch
            {

            }
           
        }
    }
}
