const express = require('express');
const mysql = require('mysql');
const multer = require('multer');
const cors = require('cors');
const bodyParser = require('body-parser');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const app = express();
app.use(cors());
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());


const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'scholarship',
});

db.connect((err) => {
  if (err) throw err;
  console.log('Connected to MySQL database');
});

const SECRET_KEY ='05282003';

const verifyToken = (req, res, next) => {
  const token = req.headers.authorization;
  
  if (!token) {
    return res.status(401).send({ error: 'No token provided' });
  }

  jwt.verify(token, SECRET_KEY, (err, decoded) => {
    if (err) {
      return res.status(401).send({ error: 'Invalid token' });
    }
    next();
  });
};

// Create account endpoint
app.post('/create-account', (req, res) => {
  const { username, password } = req.query;

  if (!username || !password ) {
    res.status(400).send({ error: 'Missing parameter or role ID error' });
    return;
  }

  const token = jwt.sign({ username }, SECRET_KEY); // Generate JWT token

  bcrypt.hash(password, 10, (err, hashedPassword) => {
    if (err) {
      console.error('Error hashing password:', err);
      res.status(500).send({ error: 'Error creating account' });
      return;
    }
    const query =
    "INSERT INTO `account`(`username`, `password`, `token`) VALUES (?,?,?)"; 

    db.query(query, [username, hashedPassword, Token], (err, result) => {
      if (err) {
        console.error('Error creating account:', err);
        res.status(500).send({ error: 'Error creating account' });
      } else {
        res.status(200).send({ message: 'Account created successfully' });
      }
    });
  });
});

app.post('/login', (req, res) => {
  const { username, password } = req.query;
console.log(req.query);
  if (!username || !password) {
    res.status(400).send({ error: 'Missing username or password' });
    return;
  }

  const query =
  "SELECT * FROM `account` WHERE username=?";
  
  db.query(query, [username], (err, result) => {
    if (err) {
      res.status(500).send({ error: 'Error fetching data' });
      return;
    }
    if (result.length === 0) {
      res.status(401).send({ error: 'Invalid credentials' });
      return;
    }
    const hashedPassword = result[0].password;
    bcrypt.compare(password, hashedPassword, (err, passwordMatch) => {
      if (err) {
        res.status(500).send({ error: 'Error logging in' });
        return;
      }

      if (passwordMatch) {
        res.status(200).send(result);
      } else {
        res.status(401).send({ error: 'Invalid password' });
      }
    });
  });
});


app.get('/student', verifyToken, (req, res) => {
  const sqlQuery =  "SELECT * FROM `student` " ;
  
  db.query(sqlQuery, (err, result) => {
    if (err) {
      res.status(500).send({ error: 'Error fetching data' });
    } else {
      res.status(200).send(result);
    }
  });
  
});


app.put('/scholarship', verifyToken, (req, res) => {
  const {First_Name,Last_Name,Gender,Address,Year_level,Course,Birthday,Scholarship,Student_id}=req.query;
  const query = "UPDATE `student` SET `First_Name`=?,`Last_Name`=?,`Gender`=?,`Address`=?,`Year_level`= ?,`Course`= ?,`Birthday`= ?,`Scholarship`= ? WHERE Student_id=?";
  db.query(query, [First_Name,Last_Name,Gender,Address,Year_level,Course,Birthday,Scholarship,Student_id], (err, result) => {
    if (err) {
      res.status(500).send({ error: 'Error' });
    } else {
      res.status(200).send({ message: 'Successfully updated' });
    }
  });
});


app.post('/scholarship', verifyToken, (req, res) => {
  const {First_Name,Last_Name,Gender,Address,Year_level,Course,Birthday,Scholarship}=req.query;
  const query = "INSERT INTO `student`( `First_Name`, `Last_Name`, `Gender`, `Address`, `Year_level`, `Course`, `Birthday`, `Scholarship`) VALUES( ?,? , ? , ? , ? , ? ,?,?)";
  db.query(query, [CustomerId,Name,Address,PhoneNumber], (err, result) => {
    if (err) {
      res.status(500).send({ error: 'Error' });
    } else {
      res.status(200).send({ message: 'Successfully inserted' });
    }
  });
});

app.delete('/scholarship', verifyToken, (req, res) => {
  const {Student_id}=req.query;
    const query = "DELETE FROM `student` WHERE Student_id =?";
    db.query(query, [Student_id], (err, result) => {
      if (err) {
        res.status(500).send({ error: 'Error' });
      } else {
        res.status(200).send({ message: 'Successfully inserted' });
      }
    });
});

app.listen(3000, () => {
  console.log('Server running on port 3000');
});
